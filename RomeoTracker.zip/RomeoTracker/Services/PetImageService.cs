﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using RomeoTracker.Models;
using RomeoTracker.Models.Entities;

namespace RomeoTracker.Services
{
    public class PetImageService
    {
        ApplicationDbContext context;

        #region Constructors

        public PetImageService(ApplicationDbContext _context) 
        {
            
        }

        #endregion

        #region CRUD



        #endregion

    }
}